-- Script para verificar las restricciones de la tabla cuentas

-- Ver estructura de la tabla cuentas
DESCRIBE cuentas;

-- Ver todas las restricciones de clave foránea
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM 
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE 
    TABLE_SCHEMA = 'agrobanco_salvadoreno'
    AND TABLE_NAME = 'cuentas'
    AND REFERENCED_TABLE_NAME IS NOT NULL;

-- Verificar si hay registros en las tablas relacionadas
SELECT 'usuarios' as tabla, COUNT(*) as total FROM usuarios
UNION ALL
SELECT 'tipos_cuenta', COUNT(*) FROM tipos_cuenta
UNION ALL
SELECT 'sucursales', COUNT(*) FROM sucursales
UNION ALL
SELECT 'roles', COUNT(*) FROM roles;

-- Ver usuarios que son clientes
SELECT u.id, u.username, u.nombre_completo, u.dui, r.nombre as rol
FROM usuarios u
JOIN roles r ON u.rol_id = r.id
WHERE r.nombre = 'cliente';

-- Ver tipos de cuenta disponibles
SELECT id, nombre, descripcion FROM tipos_cuenta;

-- Ver sucursales activas
SELECT id, nombre, codigo, estado FROM sucursales WHERE estado = 'activa';
