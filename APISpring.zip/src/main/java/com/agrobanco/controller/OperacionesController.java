package com.agrobanco.controller;

import com.agrobanco.model.Cuenta;
import com.agrobanco.service.CuentaService;
import com.agrobanco.service.TransaccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controlador específico para operaciones bancarias comunes
 * como abonos, retiros y consultas de cuentas
 */
@RestController
@RequestMapping("/operaciones")
@CrossOrigin(origins = "*")
public class OperacionesController {
    
    @Autowired
    private CuentaService cuentaService;
    
    @Autowired
    private TransaccionService transaccionService;
    
    /**
     * Obtiene las cuentas de un cliente por su DUI
     */
    @GetMapping("/cuentas/{dui}")
    public ResponseEntity<Map<String, Object>> getCuentasByDui(@PathVariable String dui) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (dui == null || dui.trim().isEmpty() || "undefined".equals(dui)) {
                response.put("success", false);
                response.put("message", "El DUI proporcionado no es válido");
                return ResponseEntity.badRequest().body(response);
            }
            
            List<Cuenta> cuentas = cuentaService.findByClienteDui(dui);
            
            response.put("success", true);
            response.put("message", "Consulta exitosa");
            response.put("cuentas", cuentas);
            response.put("total", cuentas.size());
            response.put("timestamp", LocalDateTime.now());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    /**
     * Abona efectivo a una cuenta
     */
    @PostMapping("/abonarefectivo")
    public ResponseEntity<Map<String, Object>> abonarEfectivo(@RequestBody Map<String, Object> abonoData) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String numeroCuenta = (String) abonoData.get("numeroCuenta");
            BigDecimal monto = new BigDecimal(abonoData.get("monto").toString());
            
            // Validaciones
            if (numeroCuenta == null || numeroCuenta.trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "El número de cuenta es requerido");
                return ResponseEntity.badRequest().body(response);
            }
            
            if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
                response.put("success", false);
                response.put("message", "El monto debe ser mayor que cero");
                return ResponseEntity.badRequest().body(response);
            }
            
            // Realizar el abono
            Cuenta cuentaActualizada = cuentaService.abonarEfectivo(numeroCuenta, monto);
            
            // Preparar respuesta
            response.put("success", true);
            response.put("message", "Abono realizado exitosamente");
            response.put("numeroCuenta", numeroCuenta);
            response.put("montoAbonado", monto);
            response.put("saldoActual", cuentaActualizada.getSaldo());
            response.put("timestamp", LocalDateTime.now());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
    
    /**
     * Retira efectivo de una cuenta
     */
    @PostMapping("/retirarefectivo")
    public ResponseEntity<Map<String, Object>> retirarEfectivo(@RequestBody Map<String, Object> retiroData) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            String numeroCuenta = (String) retiroData.get("numeroCuenta");
            BigDecimal monto = new BigDecimal(retiroData.get("monto").toString());
            
            // Validaciones
            if (numeroCuenta == null || numeroCuenta.trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "El número de cuenta es requerido");
                return ResponseEntity.badRequest().body(response);
            }
            
            if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0) {
                response.put("success", false);
                response.put("message", "El monto debe ser mayor que cero");
                return ResponseEntity.badRequest().body(response);
            }
            
            // Realizar el retiro
            Cuenta cuentaActualizada = cuentaService.retirarEfectivo(numeroCuenta, monto);
            
            // Preparar respuesta
            response.put("success", true);
            response.put("message", "Retiro realizado exitosamente");
            response.put("numeroCuenta", numeroCuenta);
            response.put("montoRetirado", monto);
            response.put("saldoActual", cuentaActualizada.getSaldo());
            response.put("timestamp", LocalDateTime.now());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
    
    /**
     * Consulta el saldo de una cuenta
     */
    @GetMapping("/saldo/{numeroCuenta}")
    public ResponseEntity<Map<String, Object>> consultarSaldo(@PathVariable String numeroCuenta) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            if (numeroCuenta == null || numeroCuenta.trim().isEmpty()) {
                response.put("success", false);
                response.put("message", "El número de cuenta es requerido");
                return ResponseEntity.badRequest().body(response);
            }
            
            Cuenta cuenta = cuentaService.findByNumeroCuenta(numeroCuenta)
                    .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
            
            response.put("success", true);
            response.put("message", "Consulta exitosa");
            response.put("numeroCuenta", numeroCuenta);
            response.put("saldo", cuenta.getSaldo());
            response.put("estado", cuenta.getEstado());
            response.put("tipoCuenta", cuenta.getTipoCuenta().getNombre());
            response.put("cliente", cuenta.getCliente().getNombreCompleto());
            response.put("timestamp", LocalDateTime.now());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
}
