package com.agrobanco.controller;

import com.agrobanco.model.*;
import com.agrobanco.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Controlador para crear datos de prueba y verificar el estado de la base de datos
 */
@RestController
@RequestMapping("/test")
@CrossOrigin(origins = "*")
public class TestDataController {
    
    @Autowired
    private RolRepository rolRepository;
    
    @Autowired
    private SucursalRepository sucursalRepository;
    
    @Autowired
    private TipoCuentaRepository tipoCuentaRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @GetMapping("/verificar-datos")
    public ResponseEntity<Map<String, Object>> verificarDatos() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Verificar roles
            long rolesCount = rolRepository.count();
            response.put("totalRoles", rolesCount);
            response.put("roles", rolRepository.findAll());
            
            // Verificar sucursales
            long sucursalesCount = sucursalRepository.count();
            response.put("totalSucursales", sucursalesCount);
            response.put("sucursales", sucursalRepository.findAll());
            
            // Verificar tipos de cuenta
            long tiposCuentaCount = tipoCuentaRepository.count();
            response.put("totalTiposCuenta", tiposCuentaCount);
            response.put("tiposCuenta", tipoCuentaRepository.findAll());
            
            // Verificar usuarios tipo cliente
            long clientesCount = usuarioRepository.findByRolNombre("cliente").size();
            response.put("totalClientes", clientesCount);
            response.put("clientes", usuarioRepository.findByRolNombre("cliente"));
            
            response.put("success", true);
            response.put("message", "Verificación completada");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error al verificar datos: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(response);
        }
    }
    
    @PostMapping("/crear-datos-basicos")
    public ResponseEntity<Map<String, Object>> crearDatosBasicos() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Crear roles si no existen
            if (rolRepository.count() == 0) {
                Rol rolCliente = new Rol("cliente", "Cliente del banco");
                Rol rolCajero = new Rol("cajero", "Cajero del banco");
                Rol rolGerente = new Rol("gerente", "Gerente de sucursal");
                Rol rolAdmin = new Rol("admin", "Administrador del sistema");
                
                rolRepository.save(rolCliente);
                rolRepository.save(rolCajero);
                rolRepository.save(rolGerente);
                rolRepository.save(rolAdmin);
                
                response.put("rolesCreados", 4);
            }
            
            // Crear sucursales si no existen
            if (sucursalRepository.count() == 0) {
                Sucursal sucursal1 = new Sucursal();
                sucursal1.setNombre("Sucursal Central");
                sucursal1.setCodigo("SUC001");
                sucursal1.setDepartamento("San Salvador");
                sucursal1.setMunicipio("San Salvador");
                sucursal1.setDireccion("Av. Principal #123");
                sucursal1.setTelefono("2222-2222");
                sucursal1.setEmail("central@agrobanco.com.sv");
                sucursal1.setTipo(Sucursal.TipoSucursal.standard);
                sucursal1.setEstado(Sucursal.EstadoSucursal.activa);
                
                sucursalRepository.save(sucursal1);
                response.put("sucursalesCreadas", 1);
            }
            
            // Crear tipos de cuenta si no existen
            if (tipoCuentaRepository.count() == 0) {
                TipoCuenta ahorros = new TipoCuenta();
                ahorros.setNombre("Ahorros");
                ahorros.setDescripcion("Cuenta de ahorros estándar");
                ahorros.setTasaInteres(new BigDecimal("0.0150"));
                ahorros.setMontoMinimo(new BigDecimal("5.00"));
                ahorros.setComisionMantenimiento(BigDecimal.ZERO);
                
                TipoCuenta corriente = new TipoCuenta();
                corriente.setNombre("Corriente");
                corriente.setDescripcion("Cuenta corriente para transacciones frecuentes");
                corriente.setTasaInteres(BigDecimal.ZERO);
                corriente.setMontoMinimo(new BigDecimal("25.00"));
                corriente.setComisionMantenimiento(new BigDecimal("5.00"));
                
                tipoCuentaRepository.save(ahorros);
                tipoCuentaRepository.save(corriente);
                response.put("tiposCuentaCreados", 2);
            }
            
            // Crear un cliente de prueba si no existe
            if (usuarioRepository.findByRolNombre("cliente").isEmpty()) {
                Rol rolCliente = rolRepository.findByNombre("cliente")
                        .orElseThrow(() -> new RuntimeException("Rol cliente no encontrado"));
                
                Sucursal sucursal = sucursalRepository.findAll().get(0);
                
                Usuario clientePrueba = new Usuario();
                clientePrueba.setUsername("cliente1");
                clientePrueba.setEmail("cliente1@test.com");
                clientePrueba.setPasswordHash("1234"); // En producción usar BCrypt
                clientePrueba.setNombreCompleto("Juan Pérez García");
                clientePrueba.setDui("12345678-9");
                clientePrueba.setTelefono("7777-7777");
                clientePrueba.setDireccion("Col. Las Flores, Casa #45");
                clientePrueba.setFechaNacimiento(LocalDate.of(1990, 5, 15));
                clientePrueba.setGenero(Usuario.Genero.M);
                clientePrueba.setProfesion("Agricultor");
                clientePrueba.setSalario(new BigDecimal("800.00"));
                clientePrueba.setRol(rolCliente);
                clientePrueba.setSucursal(sucursal);
                clientePrueba.setEstado(Usuario.EstadoUsuario.activo);
                
                usuarioRepository.save(clientePrueba);
                response.put("clientesCreados", 1);
                response.put("clienteId", clientePrueba.getId());
            } else {
                Usuario cliente = usuarioRepository.findByRolNombre("cliente").get(0);
                response.put("clienteExistente", cliente.getId());
            }
            
            response.put("success", true);
            response.put("message", "Datos básicos creados exitosamente");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error al crear datos básicos: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(response);
        }
    }
    
    @GetMapping("/crear-cuenta-prueba")
    public ResponseEntity<Map<String, Object>> crearCuentaPrueba() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Verificar que existan los datos necesarios
            if (rolRepository.count() == 0 || sucursalRepository.count() == 0 || 
                tipoCuentaRepository.count() == 0 || usuarioRepository.findByRolNombre("cliente").isEmpty()) {
                
                response.put("success", false);
                response.put("message", "Primero debe crear los datos básicos con /test/crear-datos-basicos");
                return ResponseEntity.badRequest().body(response);
            }
            
            // Obtener datos necesarios
            Usuario cliente = usuarioRepository.findByRolNombre("cliente").get(0);
            TipoCuenta tipoCuenta = tipoCuentaRepository.findAll().get(0);
            Sucursal sucursal = sucursalRepository.findAll().get(0);
            
            // Crear objeto para la solicitud
            Map<String, Object> cuentaData = new HashMap<>();
            cuentaData.put("clienteId", cliente.getId());
            cuentaData.put("tipoCuentaId", tipoCuenta.getId());
            cuentaData.put("sucursalId", sucursal.getId());
            cuentaData.put("saldo", 100.00);
            
            // Llamar al controlador de cuentas
            CuentaController cuentaController = new CuentaController();
            
            // Mostrar datos que se enviarán
            response.put("datosEnviados", cuentaData);
            response.put("clienteId", cliente.getId());
            response.put("tipoCuentaId", tipoCuenta.getId());
            response.put("sucursalId", sucursal.getId());
            
            response.put("success", true);
            response.put("message", "Datos para crear cuenta preparados");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Error al preparar datos para cuenta: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().body(response);
        }
    }
}
