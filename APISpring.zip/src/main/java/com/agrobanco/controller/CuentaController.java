package com.agrobanco.controller;

import com.agrobanco.model.Cuenta;
import com.agrobanco.model.TipoCuenta;
import com.agrobanco.model.Sucursal;
import com.agrobanco.model.Usuario;
import com.agrobanco.service.CuentaService;
import com.agrobanco.service.UsuarioService;
import com.agrobanco.service.TipoCuentaService;
import com.agrobanco.service.SucursalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/cuentas")
@CrossOrigin(origins = "*")
public class CuentaController {

    @Autowired
    private CuentaService cuentaService;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private TipoCuentaService tipoCuentaService;
    
    @Autowired
    private SucursalService sucursalService;

    @PostMapping
    public ResponseEntity<Map<String, Object>> createCuenta(@RequestBody Map<String, Object> cuentaData) {
        Map<String, Object> response = new HashMap<>();
        try {
            // Validar datos de entrada
            if (cuentaData == null || cuentaData.isEmpty()) {
                response.put("success", false);
                response.put("message", "Datos de cuenta requeridos");
                return ResponseEntity.badRequest().body(response);
            }

            // Crear objeto Cuenta
            Cuenta cuenta = new Cuenta();

            // Cliente - CARGAR ENTIDAD COMPLETA
            if (cuentaData.containsKey("clienteId")) {
                Integer clienteId = Integer.valueOf(cuentaData.get("clienteId").toString());
                Usuario cliente = usuarioService.findById(clienteId)
                    .orElseThrow(() -> new RuntimeException("Cliente no encontrado con ID: " + clienteId));
                cuenta.setCliente(cliente);
                
                // Log para depuración
                System.out.println("Cliente cargado: " + cliente.getId() + " - " + cliente.getNombreCompleto());
            } else {
                response.put("success", false);
                response.put("message", "El ID del cliente es requerido");
                return ResponseEntity.badRequest().body(response);
            }

            // Tipo de cuenta - CARGAR ENTIDAD COMPLETA
            if (cuentaData.containsKey("tipoCuentaId")) {
                Integer tipoCuentaId = Integer.valueOf(cuentaData.get("tipoCuentaId").toString());
                TipoCuenta tipoCuenta = tipoCuentaService.findById(tipoCuentaId)
                    .orElseThrow(() -> new RuntimeException("Tipo de cuenta no encontrado con ID: " + tipoCuentaId));
                cuenta.setTipoCuenta(tipoCuenta);
                
                // Log para depuración
                System.out.println("Tipo de cuenta cargado: " + tipoCuenta.getId() + " - " + tipoCuenta.getNombre());
            } else {
                response.put("success", false);
                response.put("message", "El tipo de cuenta es requerido");
                return ResponseEntity.badRequest().body(response);
            }

            // Sucursal - CARGAR ENTIDAD COMPLETA
            if (cuentaData.containsKey("sucursalId")) {
                Integer sucursalId = Integer.valueOf(cuentaData.get("sucursalId").toString());
                Sucursal sucursal = sucursalService.findById(sucursalId)
                    .orElseThrow(() -> new RuntimeException("Sucursal no encontrada con ID: " + sucursalId));
                cuenta.setSucursal(sucursal);
                
                // Log para depuración
                System.out.println("Sucursal cargada: " + sucursal.getId() + " - " + sucursal.getNombre());
            } else {
                response.put("success", false);
                response.put("message", "La sucursal es requerida");
                return ResponseEntity.badRequest().body(response);
            }

            // Campos opcionales
            if (cuentaData.containsKey("saldo")) {
                cuenta.setSaldo(new BigDecimal(cuentaData.get("saldo").toString()));
            } else {
                cuenta.setSaldo(BigDecimal.ZERO); // Valor por defecto
            }

            if (cuentaData.containsKey("tieneSeguro")) {
                cuenta.setTieneSeguro(Boolean.valueOf(cuentaData.get("tieneSeguro").toString()));
            } else {
                cuenta.setTieneSeguro(false); // Valor por defecto
            }

            // Imprimir objeto cuenta antes de guardar (para depuración)
            System.out.println("Cuenta a guardar: " + cuenta);
            System.out.println("Cliente ID: " + (cuenta.getCliente() != null ? cuenta.getCliente().getId() : "null"));
            System.out.println("Tipo Cuenta ID: " + (cuenta.getTipoCuenta() != null ? cuenta.getTipoCuenta().getId() : "null"));
            System.out.println("Sucursal ID: " + (cuenta.getSucursal() != null ? cuenta.getSucursal().getId() : "null"));

            // Guardar cuenta
            Cuenta nuevaCuenta = cuentaService.save(cuenta);

            response.put("success", true);
            response.put("message", "Cuenta creada exitosamente");
            response.put("cuenta", nuevaCuenta);
            response.put("numeroCuenta", nuevaCuenta.getNumeroCuenta());

            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (NumberFormatException e) {
            response.put("success", false);
            response.put("message", "Error en el formato de los datos numéricos: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", e.getMessage());
            response.put("error", e.getClass().getSimpleName());

            // Log detallado
            System.err.println("Error creando cuenta: " + e.getMessage());
            e.printStackTrace();

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
}
