package com.agrobanco.service;

import com.agrobanco.model.Cuenta;
import com.agrobanco.model.Usuario;
import com.agrobanco.repository.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class CuentaService {

    @Autowired
    private CuentaRepository cuentaRepository;

    @Transactional(readOnly = true)
    public List<Cuenta> findAll() {
        return cuentaRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Optional<Cuenta> findById(Integer id) {
        return cuentaRepository.findById(id);
    }

    @Transactional(readOnly = true)
    public Optional<Cuenta> findByNumeroCuenta(String numeroCuenta) {
        return cuentaRepository.findByNumeroCuenta(numeroCuenta);
    }

    @Transactional(readOnly = true)
    public List<Cuenta> findByClienteId(Integer clienteId) {
        return cuentaRepository.findByClienteId(clienteId);
    }

    private String generarNumeroCuenta() {
        String numeroCuenta;
        do {
            Random random = new Random();
            numeroCuenta = String.format("%010d", random.nextInt(1000000000)); // Número de 10 dígitos
        } while (cuentaRepository.existsByNumeroCuenta(numeroCuenta));
        return numeroCuenta;
    }

    @Transactional
    public Cuenta save(Cuenta cuenta) {
        // Validaciones básicas
        if (cuenta.getCliente() == null) {
            throw new RuntimeException("El cliente es requerido para crear una cuenta");
        }

        if (cuenta.getTipoCuenta() == null) {
            throw new RuntimeException("El tipo de cuenta es requerido");
        }

        if (cuenta.getSucursal() == null) {
            throw new RuntimeException("La sucursal es requerida");
        }

        // Verificar que los IDs no sean nulos
        if (cuenta.getCliente().getId() == null) {
            throw new RuntimeException("El ID del cliente no puede ser nulo");
        }

        if (cuenta.getTipoCuenta().getId() == null) {
            throw new RuntimeException("El ID del tipo de cuenta no puede ser nulo");
        }

        if (cuenta.getSucursal().getId() == null) {
            throw new RuntimeException("El ID de la sucursal no puede ser nulo");
        }

        // Generar número de cuenta si no existe
        if (cuenta.getNumeroCuenta() == null || cuenta.getNumeroCuenta().isEmpty()) {
            cuenta.setNumeroCuenta(generarNumeroCuenta());
        }

        // Validar que el número de cuenta no exista
        if (cuentaRepository.existsByNumeroCuenta(cuenta.getNumeroCuenta())) {
            throw new RuntimeException("El número de cuenta ya existe");
        }

        // Establecer valores por defecto
        if (cuenta.getSaldo() == null) {
            cuenta.setSaldo(BigDecimal.ZERO);
        }

        if (cuenta.getEstado() == null) {
            cuenta.setEstado(Cuenta.EstadoCuenta.activa);
        }

        if (cuenta.getFechaApertura() == null) {
            cuenta.setFechaApertura(LocalDate.now());
        }

        if (cuenta.getCreatedAt() == null) {
            cuenta.setCreatedAt(LocalDateTime.now());
        }

        if (cuenta.getUpdatedAt() == null) {
            cuenta.setUpdatedAt(LocalDateTime.now());
        }

        // Log para depuración
        System.out.println("Guardando cuenta: " + cuenta);
        System.out.println("Cliente ID: " + cuenta.getCliente().getId());
        System.out.println("Tipo Cuenta ID: " + cuenta.getTipoCuenta().getId());
        System.out.println("Sucursal ID: " + cuenta.getSucursal().getId());

        try {
            return cuentaRepository.save(cuenta);
        } catch (Exception e) {
            System.err.println("Error al guardar cuenta: " + e.getMessage());
            if (e.getCause() != null) {
                System.err.println("Causa: " + e.getCause().getMessage());
            }
            e.printStackTrace();
            throw new RuntimeException("Error al crear la cuenta: " + e.getMessage(), e);
        }
    }

    @Transactional
    public Cuenta abonarEfectivo(String numeroCuenta, BigDecimal monto) {
        Cuenta cuenta = cuentaRepository.findByNumeroCuenta(numeroCuenta)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada con número: " + numeroCuenta));

        if (cuenta.getEstado() != Cuenta.EstadoCuenta.activa) {
            throw new RuntimeException("La cuenta no está activa");
        }

        cuenta.setSaldo(cuenta.getSaldo().add(monto));
        cuenta.setUpdatedAt(LocalDateTime.now());

        return cuentaRepository.save(cuenta);
    }

    @Transactional
    public Cuenta retirarEfectivo(String numeroCuenta, BigDecimal monto) {
        Cuenta cuenta = cuentaRepository.findByNumeroCuenta(numeroCuenta)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada con número: " + numeroCuenta));

        if (cuenta.getEstado() != Cuenta.EstadoCuenta.activa) {
            throw new RuntimeException("La cuenta no está activa");
        }

        if (cuenta.getSaldo().compareTo(monto) < 0) {
            throw new RuntimeException("Saldo insuficiente para realizar el retiro");
        }

        cuenta.setSaldo(cuenta.getSaldo().subtract(monto));
        cuenta.setUpdatedAt(LocalDateTime.now());

        return cuentaRepository.save(cuenta);
    }
}
