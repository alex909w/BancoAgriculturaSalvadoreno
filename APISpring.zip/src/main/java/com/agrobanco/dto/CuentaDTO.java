package com.agrobanco.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * DTO para transferir datos de cuenta sin problemas de serialización
 */
public class CuentaDTO {
    
    private Integer id;
    private String numeroCuenta;
    private Integer clienteId;
    private String clienteNombre;
    private Integer tipoCuentaId;
    private String tipoCuentaNombre;
    private Integer sucursalId;
    private String sucursalNombre;
    private BigDecimal saldo;
    private String estado;
    private Boolean tieneSeguro;
    private LocalDate fechaApertura;
    
    // Constructores
    public CuentaDTO() {}
    
    // Getters y Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    
    public String getNumeroCuenta() { return numeroCuenta; }
    public void setNumeroCuenta(String numeroCuenta) { this.numeroCuenta = numeroCuenta; }
    
    public Integer getClienteId() { return clienteId; }
    public void setClienteId(Integer clienteId) { this.clienteId = clienteId; }
    
    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }
    
    public Integer getTipoCuentaId() { return tipoCuentaId; }
    public void setTipoCuentaId(Integer tipoCuentaId) { this.tipoCuentaId = tipoCuentaId; }
    
    public String getTipoCuentaNombre() { return tipoCuentaNombre; }
    public void setTipoCuentaNombre(String tipoCuentaNombre) { this.tipoCuentaNombre = tipoCuentaNombre; }
    
    public Integer getSucursalId() { return sucursalId; }
    public void setSucursalId(Integer sucursalId) { this.sucursalId = sucursalId; }
    
    public String getSucursalNombre() { return sucursalNombre; }
    public void setSucursalNombre(String sucursalNombre) { this.sucursalNombre = sucursalNombre; }
    
    public BigDecimal getSaldo() { return saldo; }
    public void setSaldo(BigDecimal saldo) { this.saldo = saldo; }
    
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    
    public Boolean getTieneSeguro() { return tieneSeguro; }
    public void setTieneSeguro(Boolean tieneSeguro) { this.tieneSeguro = tieneSeguro; }
    
    public LocalDate getFechaApertura() { return fechaApertura; }
    public void setFechaApertura(LocalDate fechaApertura) { this.fechaApertura = fechaApertura; }
}
