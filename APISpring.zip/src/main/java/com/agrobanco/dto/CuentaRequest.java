package com.agrobanco.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.DecimalMin;
import java.math.BigDecimal;

/**
 * DTO para la creación de cuentas con validación
 */
public class CuentaRequest {
    
    @NotNull(message = "El ID del cliente es requerido")
    private Integer clienteId;
    
    @NotNull(message = "El ID del tipo de cuenta es requerido")
    private Integer tipoCuentaId;
    
    @NotNull(message = "El ID de la sucursal es requerido")
    private Integer sucursalId;
    
    @DecimalMin(value = "0.0", message = "El saldo inicial no puede ser negativo")
    private BigDecimal saldoInicial = BigDecimal.ZERO;
    
    private Boolean tieneSeguro = false;
    
    // Constructores
    public CuentaRequest() {}
    
    // Getters y Setters
    public Integer getClienteId() {
        return clienteId;
    }
    
    public void setClienteId(Integer clienteId) {
        this.clienteId = clienteId;
    }
    
    public Integer getTipoCuentaId() {
        return tipoCuentaId;
    }
    
    public void setTipoCuentaId(Integer tipoCuentaId) {
        this.tipoCuentaId = tipoCuentaId;
    }
    
    public Integer getSucursalId() {
        return sucursalId;
    }
    
    public void setSucursalId(Integer sucursalId) {
        this.sucursalId = sucursalId;
    }
    
    public BigDecimal getSaldoInicial() {
        return saldoInicial;
    }
    
    public void setSaldoInicial(BigDecimal saldoInicial) {
        this.saldoInicial = saldoInicial;
    }
    
    public Boolean getTieneSeguro() {
        return tieneSeguro;
    }
    
    public void setTieneSeguro(Boolean tieneSeguro) {
        this.tieneSeguro = tieneSeguro;
    }
    
    @Override
    public String toString() {
        return "CuentaRequest{" +
                "clienteId=" + clienteId +
                ", tipoCuentaId=" + tipoCuentaId +
                ", sucursalId=" + sucursalId +
                ", saldoInicial=" + saldoInicial +
                ", tieneSeguro=" + tieneSeguro +
                '}';
    }
}
