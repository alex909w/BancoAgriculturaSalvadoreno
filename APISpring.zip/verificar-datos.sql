-- Script para verificar los datos en la base de datos

-- Ver tablas existentes
SHOW TABLES;

-- Ver estructura de la tabla cuentas
DESCRIBE cuentas;

-- Ver datos en la tabla roles
SELECT * FROM roles;

-- Ver datos en la tabla sucursales
SELECT * FROM sucursales;

-- Ver datos en la tabla tipos_cuenta
SELECT * FROM tipos_cuenta;

-- Ver usuarios que son clientes
SELECT u.id, u.username, u.nombre_completo, u.dui, r.nombre as rol
FROM usuarios u
JOIN roles r ON u.rol_id = r.id
WHERE r.nombre = 'cliente';

-- Ver restricciones de clave foránea en la tabla cuentas
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    COLUMN_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM 
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE 
    TABLE_SCHEMA = 'agrobanco_salvadoreno'
    AND TABLE_NAME = 'cuentas'
    AND REFERENCED_TABLE_NAME IS NOT NULL;
