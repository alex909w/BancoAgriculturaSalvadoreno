"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { cuentasAPI } from "@/lib/api"

// Define una interfaz para el tipo de cuenta
interface Account {
  id?: number
  numero: string
  saldo: string
  tipo?: string
}

export default function DashboardCliente() {
  const router = useRouter()
  const [menuVisible, setMenuVisible] = useState(false)
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null)
  const [modalVisible, setModalVisible] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Datos de ejemplo para mostrar en la interfaz
  const [accounts, setAccounts] = useState<Account[]>([
    { numero: "652732736823", saldo: "75.45 US" },
    { numero: "657687676666", saldo: "232.00 US" },
  ])

  useEffect(() => {
    // Verificar autenticación
    const authToken = localStorage.getItem("authToken")
    const userRole = localStorage.getItem("userRole")

    if (!authToken || userRole !== "cliente") {
      router.push("/login")
      return
    }

    // Intentar cargar datos reales
    loadClientData()
  }, [router])

  const loadClientData = async () => {
    try {
      const clienteId = localStorage.getItem("userId")

      if (clienteId) {
        // Intentar cargar cuentas del cliente
        const cuentasResponse = await cuentasAPI.getByCliente(Number.parseInt(clienteId))

        if (!cuentasResponse.error && cuentasResponse.length > 0) {
          const formattedAccounts = cuentasResponse.map((cuenta: any) => ({
            id: cuenta.id,
            numero: cuenta.numero,
            saldo: `${cuenta.saldo.toFixed(2)} US`,
            tipo: cuenta.tipo,
          }))
          setAccounts(formattedAccounts)
        }
      }
    } catch (error) {
      console.error("Error al cargar datos del cliente:", error)
      // Mantenemos los datos de ejemplo como respaldo
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("authToken")
    localStorage.removeItem("userRole")
    localStorage.removeItem("userName")
    localStorage.removeItem("userId")
    router.push("/login")
  }

  const toggleMenu = () => {
    setMenuVisible(!menuVisible)
  }

  const handleDetailsClick = (account: Account) => {
    setSelectedAccount(account)
    setModalVisible(true)
  }

  const closeModal = () => {
    setModalVisible(false)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-green-500"></div>
          <p className="mt-2 text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-green-600 shadow-md p-4 flex justify-between items-center">
        <div className="flex items-center">
          <img src="/imagenes/logo.png" alt="AgroBanco Salvadoreño Logo" className="h-12" />
          <span className="ml-2 text-white text-lg">AgroBanco Salvadoreño</span>
        </div>
        <h1 className="text-xl font-bold text-white">Panel de Clientes</h1>
        <div className="relative">
          <button className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200" onClick={toggleMenu}>
            <img src="/imagenes/Usuario.png" alt="Usuario" className="w-8 h-8 rounded-full" />
          </button>

          {menuVisible && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
              <Link href="/perfil-cliente" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                Perfil
              </Link>
              <Link href="/configuracion-cliente" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                Configuración
              </Link>
              <button
                onClick={handleLogout}
                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Cerrar Sesión
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 p-6">
        <h2 className="text-2xl font-bold text-center mb-6">Información Usuario</h2>

        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1 space-y-4">
              {accounts.map((account, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
                  <p className="text-gray-700 mb-2">
                    Número de cuenta: <span className="font-medium">{account.numero}</span>
                  </p>
                  <p className="text-green-700 font-bold text-2xl mb-3">{account.saldo}</p>
                  <button
                    className="bg-gray-300 text-gray-800 py-2 px-6 rounded hover:bg-gray-400 transition-colors"
                    onClick={() => handleDetailsClick(account)}
                  >
                    Detalles
                  </button>
                </div>
              ))}
            </div>

            <div className="flex-1 bg-white p-8 rounded-lg shadow-md flex flex-col items-center">
              <img src="/imagenes/usuario.png" alt="Usuario" className="w-32 h-32 mb-4" />
              <h3 className="text-xl font-bold text-center mb-4">JOSÉ ALEXANDER RAMOS HERNÁNDEZ</h3>
              <div className="text-center space-y-2">
                <p className="text-gray-700">TIPO DE CUENTA: PRESTAMISTA</p>
                <p className="text-gray-700">ID. DE CLIENTE: 15093293JR</p>
                <p className="text-gray-700">PROFESIÓN: AGRICULTOR</p>
                <p className="text-gray-700">CUENTAS EN POSESIÓN: 2</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <div className="bg-white rounded-lg shadow-md p-8 flex flex-col items-center hover:bg-gray-50 transition-colors">
              <img src="/imagenes/movimiento.png" alt="Crear Otra Cuenta" className="w-20 h-20 mb-4" />
              <span className="text-lg font-medium text-gray-800">CREAR OTRA CUENTA</span>
              <button
                onClick={() => router.push("/nueva-cuenta-cliente")}
                className="mt-4 bg-green-600 text-white py-2 px-6 rounded hover:bg-green-700 transition-colors"
              >
                Ir
              </button>
            </div>

            <div className="bg-white rounded-lg shadow-md p-8 flex flex-col items-center hover:bg-gray-50 transition-colors">
              <img src="/imagenes/historial.png" alt="Historial de Transacciones" className="w-20 h-20 mb-4" />
              <span className="text-lg font-medium text-gray-800">HISTORIAL DE TRANSACCIONES</span>
              <button
                onClick={() => router.push("/historial-transacciones")}
                className="mt-4 bg-green-600 text-white py-2 px-6 rounded hover:bg-green-700 transition-colors"
              >
                Ir
              </button>
            </div>
          </div>
        </div>
      </main>

      {modalVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">Detalles de la Cuenta</h3>
              <button className="text-gray-500 hover:text-gray-700 text-2xl" onClick={closeModal}>
                ×
              </button>
            </div>

            {selectedAccount && (
              <div className="space-y-4">
                <p>
                  <strong>Número de Cuenta:</strong> {selectedAccount.numero}
                </p>
                <p>
                  <strong>Saldo:</strong> {selectedAccount.saldo}
                </p>
                <p>
                  <strong>Tipo de Cuenta:</strong> {selectedAccount.tipo || "Corriente"}
                </p>
                <p>
                  <strong>Fecha de Apertura:</strong> 15/03/2023
                </p>
                <p>
                  <strong>Estado:</strong> Activa
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
