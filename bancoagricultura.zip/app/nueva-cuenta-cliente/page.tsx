"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

export default function NuevaCuentaClientePage() {
  const router = useRouter()
  const [menuVisible, setMenuVisible] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [formData, setFormData] = useState({
    tipoCuenta: "",
    sucursal: "",
    correoElectronico: "",
    agregarBeneficiario: false,
    agregarSeguro: false,
    aceptaTerminos: false,
  })

  // Datos del cliente (simulados)
  const userData = {
    nombre: "Farmacia San Lorenzo",
    tipoCuenta: "Dependiente",
    idCliente: "150343434SL",
    giroComercial: "Farmaceutica",
    cuentasEnPosesion: 2,
  }

  useEffect(() => {
    // Verificar autenticación
    const authToken = localStorage.getItem("authToken")
    const userRole = localStorage.getItem("userRole")

    if (!authToken || userRole !== "cliente") {
      router.push("/login")
      return
    }

    // Simular carga de datos
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("authToken")
    localStorage.removeItem("userRole")
    localStorage.removeItem("userName")
    localStorage.removeItem("userId")
    router.push("/login")
  }

  const toggleMenu = () => {
    setMenuVisible(!menuVisible)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement
    const checked = type === "checkbox" ? (e.target as HTMLInputElement).checked : undefined

    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.aceptaTerminos) {
      alert("Debe aceptar los términos y condiciones")
      return
    }

    // Aquí iría la lógica para crear la cuenta
    console.log("Datos del formulario:", formData)

    // Simular éxito
    alert("Cuenta creada exitosamente")
    router.push("/dashboard-cliente")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex justify-center items-center bg-gray-50">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-green-500"></div>
          <p className="mt-2 text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-green-600 shadow-md p-4 flex justify-between items-center">
        <div className="flex items-center">
          <img src="/imagenes/logo.png" alt="AgroBanco Salvadoreño Logo" className="h-12" />
          <span className="ml-2 text-white text-lg">AgroBanco Salvadoreño</span>
        </div>
        <h1 className="text-xl font-bold text-white">Crear Nueva Cuenta</h1>
        <div className="relative">
          <button className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200" onClick={toggleMenu}>
            <img src="/imagenes/Usuario.png" alt="Usuario" className="w-8 h-8 rounded-full" />
          </button>

          {menuVisible && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
              <Link href="/perfil-cliente" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                Perfil
              </Link>
              <Link href="/configuracion-cliente" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                Configuración
              </Link>
              <button
                onClick={handleLogout}
                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
              >
                Cerrar Sesión
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 p-6">
        <div className="max-w-6xl mx-auto bg-white rounded-lg shadow-md p-6">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1">
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="tipoCuenta" className="block mb-2 font-medium">
                    Tipo de cuenta:
                  </label>
                  <select
                    id="tipoCuenta"
                    name="tipoCuenta"
                    value={formData.tipoCuenta}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md p-2"
                  >
                    <option value="">Seleccione un tipo</option>
                    <option value="Dependiente">Dependiente</option>
                    <option value="Independiente">Independiente</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="agregarBeneficiario"
                      checked={formData.agregarBeneficiario}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    Agregar beneficiario
                  </label>
                </div>

                <div className="mb-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="agregarSeguro"
                      checked={formData.agregarSeguro}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    Agregar seguro
                  </label>
                </div>

                <div className="mb-4">
                  <label htmlFor="sucursal" className="block mb-2 font-medium">
                    Sucursal de preferencia:
                  </label>
                  <select
                    id="sucursal"
                    name="sucursal"
                    value={formData.sucursal}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md p-2"
                  >
                    <option value="">Seleccione una sucursal</option>
                    <option value="Farmaceutica">Farmaceutica</option>
                    <option value="Mercado">Mercado</option>
                    <option value="Centro Comercial">Centro Comercial</option>
                    <option value="Otra Sucursal">Otra Sucursal</option>
                  </select>
                </div>

                <div className="mb-4">
                  <label htmlFor="correoElectronico" className="block mb-2 font-medium">
                    Correo electrónico:
                  </label>
                  <input
                    type="email"
                    id="correoElectronico"
                    name="correoElectronico"
                    value={formData.correoElectronico}
                    onChange={handleChange}
                    className="w-full border border-gray-300 rounded-md p-2"
                  />
                </div>

                <div className="mb-6">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="aceptaTerminos"
                      checked={formData.aceptaTerminos}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    Confirmo haber leído Términos y Condiciones
                  </label>
                </div>

                <div className="flex gap-4">
                  <button
                    type="submit"
                    className="bg-green-600 text-white py-2 px-6 rounded-md hover:bg-green-700 transition-colors"
                  >
                    Crear
                  </button>
                  <button
                    type="button"
                    onClick={() => router.push("/dashboard-cliente")}
                    className="bg-red-500 text-white py-2 px-6 rounded-md hover:bg-red-600 transition-colors"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>

            <div className="flex-1 flex flex-col items-center justify-center">
              <img src="/imagenes/usuario.png" alt="Usuario" className="w-32 h-32 mb-4" />
              <div className="text-center space-y-2">
                <p>
                  <strong>Nombre:</strong> {userData.nombre}
                </p>
                <p>
                  <strong>Tipo de Cuenta:</strong> {userData.tipoCuenta}
                </p>
                <p>
                  <strong>ID de Cliente:</strong> {userData.idCliente}
                </p>
                <p>
                  <strong>Giro Comercial:</strong> {userData.giroComercial}
                </p>
                <p>
                  <strong>Cuentas en Posesión:</strong> {userData.cuentasEnPosesion}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
