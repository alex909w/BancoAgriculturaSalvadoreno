// Configuración base de la API
const API_BASE_URL = "http://localhost:8080/api"

// Función helper para hacer peticiones
export async function apiRequest(endpoint: string, options: RequestInit = {}): Promise<any> {
  const token = localStorage.getItem("authToken")

  const defaultHeaders = {
    "Content-Type": "application/json",
    ...(token && { Authorization: `Bearer ${token}` }),
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    })

    if (!response.ok) {
      console.error(`Error API: ${response.status} ${response.statusText}`)
      // En lugar de lanzar un error, devolvemos un objeto con información del error
      // para que la aplicación pueda manejarlo sin romperse
      return {
        error: true,
        status: response.status,
        message: response.statusText || "Error en la solicitud",
      }
    }

    return response.json()
  } catch (error) {
    console.error("Error de red:", error)
    return {
      error: true,
      message: "Error de conexión. Verifique su conexión a internet o inténtelo más tarde.",
    }
  }
}

// Funciones específicas para cada endpoint

// Usuarios
export const usuariosAPI = {
  getAll: () => apiRequest("/usuarios"),
  getById: (id: number) => apiRequest(`/usuarios/${id}`),
  getByUsername: (username: string) => apiRequest(`/usuarios/username/${username}`),
  create: (data: any) => apiRequest("/usuarios", { method: "POST", body: JSON.stringify(data) }),
  update: (id: number, data: any) => apiRequest(`/usuarios/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: number) => apiRequest(`/usuarios/${id}`, { method: "DELETE" }),
  changeStatus: (id: number, estado: string) =>
    apiRequest(`/usuarios/${id}/estado`, { method: "PUT", body: JSON.stringify({ estado }) }),
}

// Cuentas
export const cuentasAPI = {
  getAll: () => apiRequest("/cuentas"),
  getById: (id: number) => apiRequest(`/cuentas/${id}`),
  getByCliente: (clienteId: number) => apiRequest(`/cuentas/cliente/${clienteId}`),
  create: (data: any) => apiRequest("/cuentas", { method: "POST", body: JSON.stringify(data) }),
  update: (id: number, data: any) => apiRequest(`/cuentas/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: number) => apiRequest(`/cuentas/${id}`, { method: "DELETE" }),
  changeStatus: (id: number, estado: string) =>
    apiRequest(`/cuentas/${id}/estado`, { method: "PUT", body: JSON.stringify({ estado }) }),
}

// Transacciones
export const transaccionesAPI = {
  getAll: () => apiRequest("/transacciones"),
  getById: (id: number) => apiRequest(`/transacciones/${id}`),
  getByCuenta: (cuentaId: number) => apiRequest(`/transacciones/cuenta/${cuentaId}`),
  deposito: (data: any) => apiRequest("/transacciones/deposito", { method: "POST", body: JSON.stringify(data) }),
  retiro: (data: any) => apiRequest("/transacciones/retiro", { method: "POST", body: JSON.stringify(data) }),
  transferencia: (data: any) =>
    apiRequest("/transacciones/transferencia", { method: "POST", body: JSON.stringify(data) }),
}

// Préstamos
export const prestamosAPI = {
  getAll: () => apiRequest("/prestamos"),
  getById: (id: number) => apiRequest(`/prestamos/${id}`),
  getByCliente: (clienteId: number) => apiRequest(`/prestamos/cliente/${clienteId}`),
  getByEstado: (estado: string) => apiRequest(`/prestamos/estado/${estado}`),
  create: (data: any) => apiRequest("/prestamos", { method: "POST", body: JSON.stringify(data) }),
  aprobar: (id: number, data: any) =>
    apiRequest(`/prestamos/${id}/aprobar`, { method: "PUT", body: JSON.stringify(data) }),
  rechazar: (id: number, data: any) =>
    apiRequest(`/prestamos/${id}/rechazar`, { method: "PUT", body: JSON.stringify(data) }),
  desembolsar: (id: number, data: any) =>
    apiRequest(`/prestamos/${id}/desembolsar`, { method: "PUT", body: JSON.stringify(data) }),
}

// Sucursales
export const sucursalesAPI = {
  getAll: () => apiRequest("/sucursales"),
  getById: (id: number) => apiRequest(`/sucursales/${id}`),
  getByCodigo: (codigo: string) => apiRequest(`/sucursales/codigo/${codigo}`),
  getByEstado: (estado: string) => apiRequest(`/sucursales/estado/${estado}`),
  create: (data: any) => apiRequest("/sucursales", { method: "POST", body: JSON.stringify(data) }),
  update: (id: number, data: any) => apiRequest(`/sucursales/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: number) => apiRequest(`/sucursales/${id}`, { method: "DELETE" }),
}

// Roles
export const rolesAPI = {
  getAll: () => apiRequest("/roles"),
  getById: (id: number) => apiRequest(`/roles/${id}`),
  getByNombre: (nombre: string) => apiRequest(`/roles/nombre/${nombre}`),
  create: (data: any) => apiRequest("/roles", { method: "POST", body: JSON.stringify(data) }),
  update: (id: number, data: any) => apiRequest(`/roles/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  delete: (id: number) => apiRequest(`/roles/${id}`, { method: "DELETE" }),
}
